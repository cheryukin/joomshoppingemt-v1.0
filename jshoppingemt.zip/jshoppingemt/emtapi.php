<?php
/**
 * @package plugin jshoppingEMT
 * @copyright (C) 2010-2013 Emailtoools
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */

defined('_JEXEC') or die('Restricted access');

class EMTApi
{
	
	protected $apiKey;
	protected $tracker_url = 'https://emailtools.ru/tracker/'; 
	protected $timeout;
	protected $origin;

	public function __construct($apiKey, $timeout = 3)
	{
		$this->apiKey = $apiKey;
		$this->timeout = $timeout;
		$this->origin = 'http' . ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ? 's' : '') . '://' . $_SERVER ['HTTP_HOST'];
	}

	public function sendOperation($task, $param)
	{
		if(!isset($_COOKIE['emt_uuuid']) || empty($_COOKIE['emt_uuuid'])) return 'error uuuid cookie';

		$param['client_id'] = $this->apiKey;
		$param['uuuid'] = $_COOKIE['emt_uuuid'];
		$param['task'] = $task;

		if (!isset($_COOKIE['emt_uuuid'])) return 'Bad uuid';

		$curl = curl_init($this->tracker_url);

		curl_setopt_array($curl, [
			CURLOPT_SSL_VERIFYPEER => false,
			CURLOPT_SSL_VERIFYHOST => false,
			CURLOPT_HTTPHEADER =>  [
				'Content-Type: application/x-www-form-urlencoded',
				'Accept: */*',
				'Origin: '.$this->origin,
			],
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => http_build_query($param),
			CURLOPT_TIMEOUT => $this->timeout
		]);

		$response = curl_exec($curl);
		curl_close($curl);

		return $response;
	}

}