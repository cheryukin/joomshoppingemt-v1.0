<?php
/**
 * @package plugin jshoppingEMT
 * @copyright (C) 2010-2013 Emailtoools
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */

defined('_JEXEC') or die('Restricted access');

require_once('emtapi.php');

class plgSystemJShoppingEMT extends JPlugin
{
	private $apikey;
	private $addLogger;

	public function __construct(& $subject, $config)
	{
		parent::__construct($subject, $config);

		$this->apikey = $this->params->get('apikey', 0);
		$this->addLogger = $this->params->get('addlogs', 0);

		if ($this->addLogger){
			JLog::addLogger(
				array('text_file' => 'emailtools.log'),
				JLog::ALL,
				array('jshoppingemt')
			);
		}
	}

	// добавляем в блок <head> общего шаблона скрипты
	public function onBeforeCompileHead()
	{
		$doc = JFactory::getDocument();
		
		$doc->addCustomTag('<script src="https://emailtools.ru/js/api/v1.1/tools.js" defer></script>');
		$doc->addCustomTag('<script>window.EMT = window.EMT || {};EMT._client_id = '.$this->apikey.';</script>');

		return;
	}

	// посетитель что-то положил в корзину
	function onAfterAddProductToCart($cart, $product_id)
	{
		$emt = new EMTApi($this->apikey);
		$result = $emt->sendOperation('addtocart', array('productid'=>$product_id));

		$this->addLog($result);

		return;
	}

	private function getOrderProductIds($order)
	{
		$result = [];
		$items = $order->getAllItems();
		foreach($items as $item){
			$result[] = $item->product_id;
		}

		return implode(',', $result);
	} 

	// посетитель оформил заказ
	function onAfterDisplayCheckoutFinish($text, $order)
	{
		$data = [
			'name' => trim(implode(' ',[$order->f_name, $order->l_name])),
			'email' => $order->email,
			'orderid' => $order->order_id,
			'products' => $this->getOrderProductIds($order),
			'total' => (int) $order->order_total,
			'permission' =>  'subscribe' // unsubscribe
		];

		$emt = new EMTApi($this->apikey);
		$result = $emt->sendOperation('sendOrder', $data);

		$this->addLog($result);

		return;
	}

	// посетитель зашел в какую-то категорию товаров
	function onBeforeDisplayProductListView($view)
	{
		$emt = new EMTApi($this->apikey);
		$result = $emt->sendOperation('viewCategory', array('categoryid'=>$view->category->category_id));

		$this->addLog($result);

		return;
	}

	// посетитель зашел в какой-то товар
	function onBeforeDisplayProductView($view)
	{
		$emt = new EMTApi($this->apikey);
		$result = $emt->sendOperation('viewProduct', array('categoryid'=>$view->category_id, 'productid'=>$view->product->product_id));

		$this->addLog($result);

		return;
	}

	// посетитель выбрал какой-то онлайн спобоб оплаты
	function onBeforeShowEndFormStep6($order, $cart, $pm_method)
	{
		$emt = new EMTApi($this->apikey);
		$result = $emt->sendOperation('onlinepay', array('email'=>$order->email));

		$this->addLog($result);

		return;
	}

	// сбрасываем всё в лог
	function addLog($str)
	{
		if ($this->addLogger){
			JLog::add($str, JLog::INFO, 'jshoppingemt');
		}
	}

}